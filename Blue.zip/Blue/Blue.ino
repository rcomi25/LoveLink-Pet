#include <Arduino.h>
#include <lvgl.h>
#include <Arduino_GFX_Library.h>
#include "ui.h"

#define TINY_GSM_MODEM_SIM7080
#define TINY_GSM_RX_BUFFER 1024
#define SerialAT Serial1
#include <TinyGsmClient.h>
#include <PubSubClient.h>
#include <Preferences.h>
#include <time.h>

#define XPOWERS_CHIP_AXP2101
#include "XPowersLib.h"
#include "utilities.h"

#include "driver/rtc_io.h"

// ============================================================================
// USER CONFIGURATION
// Change the values in this section to adapt the project to your hardware.
// ============================================================================

// -------------------- Display wiring --------------------
// ST7789 SPI display pins. Change these only if you rewire the display.
#define TFT_SCLK 12
#define TFT_MOSI 11
#define TFT_CS   10
#define TFT_DC   13
#define TFT_RST  14
#define TFT_BL   21   // Backlight PWM pin

// -------------------- Physical buttons --------------------
// Buttons must be wired like this: GPIO -> button -> GND.
// INPUT_PULLUP is used internally, so no external pull-up is required.
#define BTN_LEFT    8
#define BTN_RIGHT   18
#define BTN_UP      9
#define BTN_DOWN    45   // GPIO45 is used as DOWN, but it cannot wake from deep sleep.
#define BTN_SELECT  17

// -------------------- Deep sleep wake-up buttons --------------------
// Only RTC-capable GPIOs can wake the ESP32-S3 from deep sleep.
// GPIO45 is deliberately excluded because it is not valid for EXT1 wake-up.
const uint64_t WAKEUP_BUTTON_MASK =
  (1ULL << BTN_LEFT) |
  (1ULL << BTN_RIGHT) |
  (1ULL << BTN_UP) |
  (1ULL << BTN_SELECT);

// -------------------- MQTT / cellular settings --------------------
// Cellular APN and MQTT broker credentials.
const char APN[] = "dr.m2m.ch";

const char MQTT_HOST[]      = "84.72.188.201";
const int  MQTT_PORT        = 1883;
const char MQTT_USER[]      = "rcomi";
const char MQTT_PASS[]      = "220805Rc";
const char MQTT_CLIENT_ID[] = "LilyGO_SIM7080G_S3_B";

const char TOPIC_PUB[] = "test/topic";
const char TOPIC_SUB[] = "test/topic";

// -------------------- Automatic sleep behavior --------------------
// After DIM_AFTER_MS without button activity, the screen becomes dim.
// After DEEP_SLEEP_AFTER_MS more, the device enters deep sleep.
const unsigned long DIM_AFTER_MS        = 3UL * 60UL * 1000UL;  // 3 minutes
const unsigned long DEEP_SLEEP_AFTER_MS = 1UL * 60UL * 1000UL;  // 1 minute after dimming

const int BACKLIGHT_NORMAL = 255;  // Full display brightness, PWM 0-255
const int BACKLIGHT_DIM    = 25;   // Dimmed display brightness, PWM 0-255

// -------------------- Tamagotchi decay behavior --------------------
// Food goes from 100% to 0% in 8 hours.
// Energy goes from 100% to 0% in 20 hours.
const float FOOD_DECAY_PER_SECOND   = 100.0 / (8.0 * 60.0 * 60.0);
const float ENERGY_DECAY_PER_SECOND = 100.0 / (20.0 * 60.0 * 60.0);

// -------------------- Persistent pet state --------------------
// The pet state is saved before deep sleep and restored after wake-up.
// Offline decay is calculated using the cellular network time.
const char NVS_NAMESPACE[] = "tamagochi";
const char NVS_KEY_FOOD[] = "food";
const char NVS_KEY_ENERGY[] = "energy";
const char NVS_KEY_LAST_UNIX[] = "lastUnix";

// ============================================================================
// GLOBAL STATE
// These variables store the live state of the UI and pet.
// ============================================================================

// Screen sleep state.
unsigned long lastUserActivity = 0;
bool screenDimmed = false;

// Notification and received message state.
bool hasNotification = false;
String receivedMessages = "";

// Pet status values, shown in the UI and changed over time or via MQTT.
float foodValue = 100.0;
float energyValue = 100.0;
unsigned long lastPetUpdate = 0;
unsigned long lastSavedUnixTime = 0;

// UI mode state machine.
// MODE_BASE: normal Home / Action / Settings navigation.
// MODE_ACTION_CURSOR: cursor active on Action screen.
// MODE_SEND_CURSOR: cursor active on SendScreen.
// MODE_RECEIVED_CURSOR: ReceivedScreen open.
// MODE_MOOD_CURSOR: cursor active on MoodScreen.
enum UiMode {
  MODE_BASE,
  MODE_ACTION_CURSOR,
  MODE_SEND_CURSOR,
  MODE_RECEIVED_CURSOR,
  MODE_MOOD_CURSOR
};

UiMode uiMode = MODE_BASE;
int actionCursorIndex = 0;  // 0=Select2a, 1=Select2b, 2=Select2c, 3=Select2d
int sendCursorIndex = 0;    // 0..4 = SelectSend1..SelectSend5
int moodCursorIndex = 0;    // 0..4 = SelectMood1..SelectMood5

// Long-press detection for SELECT.
unsigned long selectPressStart = 0;
bool selectIsPressed = false;
bool selectLongHandled = false;

// Long-press detection for LEFT.
unsigned long leftPressStart = 0;
bool leftIsPressed = false;
bool leftLongHandled = false;

// Temporary confirmation label shown after sending MQTT messages.
unsigned long sendConfirmedShownAt = 0;
bool sendConfirmedVisible = false;

// ================= OBJECTS =================
XPowersPMU PMU;
TinyGsm modem(SerialAT);
TinyGsmClient gsmClient(modem);
PubSubClient mqtt(gsmClient);
Preferences prefs;

Arduino_DataBus *bus = new Arduino_ESP32SPI(
  TFT_DC,
  TFT_CS,
  TFT_SCLK,
  TFT_MOSI,
  GFX_NOT_DEFINED
);

Arduino_GFX *gfx = new Arduino_ST7789(
  bus,
  TFT_RST,
  0,
  true,
  240,
  280,
  0,
  20,
  0,
  0
);

// ================= LVGL =================
static lv_disp_draw_buf_t draw_buf;
static lv_color_t buf[240 * 40];
static lv_disp_drv_t disp_drv;

lv_obj_t *screenList[3];
const int SCREEN_COUNT = 3;
int currentScreen = 0;

// ================= TIMERS =================
unsigned long lastUiUpdate = 0;
unsigned long lastTimeUpdate = 0;

// =====================================================
// FORWARD DECLARATIONS
// =====================================================
void updatePetUI();
void showKoala(lv_obj_t *koala);
bool connectMQTT();
void setLoadingProgress(int value, const char *text);
bool waitNetworkWithUI();
void loadPetState();
void savePetState();
void applyOfflineDecay();
unsigned long getNetworkUnixTime();

// =====================================================
// DISPLAY FLUSH
// =====================================================
void my_disp_flush(lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p)
{
  uint32_t w = area->x2 - area->x1 + 1;
  uint32_t h = area->y2 - area->y1 + 1;

  gfx->draw16bitRGBBitmap(
    area->x1,
    area->y1,
    (uint16_t *)color_p,
    w,
    h
  );

  lv_disp_flush_ready(disp);
}

void hideSendCursorPanels()
{
  lv_obj_add_flag(ui_SelectSend1, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_SelectSend2, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_SelectSend3, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_SelectSend4, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_SelectSend5, LV_OBJ_FLAG_HIDDEN);
}

void showSendCursor()
{
  hideSendCursorPanels();

  if (sendCursorIndex == 0) lv_obj_clear_flag(ui_SelectSend1, LV_OBJ_FLAG_HIDDEN);
  if (sendCursorIndex == 1) lv_obj_clear_flag(ui_SelectSend2, LV_OBJ_FLAG_HIDDEN);
  if (sendCursorIndex == 2) lv_obj_clear_flag(ui_SelectSend3, LV_OBJ_FLAG_HIDDEN);
  if (sendCursorIndex == 3) lv_obj_clear_flag(ui_SelectSend4, LV_OBJ_FLAG_HIDDEN);
  if (sendCursorIndex == 4) lv_obj_clear_flag(ui_SelectSend5, LV_OBJ_FLAG_HIDDEN);
}

void enterSendScreen()
{
  uiMode = MODE_SEND_CURSOR;
  sendCursorIndex = 0;

  lv_scr_load_anim(
    ui_SendScreen,
    LV_SCR_LOAD_ANIM_MOVE_LEFT,
    250,
    0,
    false
  );

  showSendCursor();
}

void showSendConfirmed()
{
  lv_obj_clear_flag(ui_SendConfirmed, LV_OBJ_FLAG_HIDDEN);
  sendConfirmedShownAt = millis();
  sendConfirmedVisible = true;

  lv_obj_invalidate(ui_SendConfirmed);
  lv_timer_handler();
}

void handleSendConfirmedTimeout()
{
  if (sendConfirmedVisible && millis() - sendConfirmedShownAt >= 2000) {
    lv_obj_add_flag(ui_SendConfirmed, LV_OBJ_FLAG_HIDDEN);
    sendConfirmedVisible = false;
  }
}

void sendSelectedMessage()
{
  const char *msg = nullptr;

  if (sendCursorIndex == 0) msg = "d_tiamo";
  else if (sendCursorIndex == 1) msg = "d_mimanchi";
  else if (sendCursorIndex == 2) msg = "d_food";
  else if (sendCursorIndex == 3) msg = "d_energy";
  else if (sendCursorIndex == 4) msg = "d_sonoarrabbiato";

  if (msg == nullptr) return;

  if (!mqtt.connected() && modem.isNetworkConnected()) {
    connectMQTT();
  }

  if (mqtt.connected()) {
    mqtt.publish(TOPIC_PUB, msg);
    Serial.print("MQTT SEND: ");
    Serial.println(msg);

    showSendConfirmed();

    // Piccola pausa richiesta dopo invio messaggio da SendScreen
    delay(1000);
  } else {
    Serial.println("MQTT send failed: disconnected");
  }
}


void hideMoodCursorPanels()
{
  lv_obj_add_flag(ui_SelectMood1, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_SelectMood2, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_SelectMood3, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_SelectMood4, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_SelectMood5, LV_OBJ_FLAG_HIDDEN);
}

void showMoodCursor()
{
  hideMoodCursorPanels();

  if (moodCursorIndex == 0) lv_obj_clear_flag(ui_SelectMood1, LV_OBJ_FLAG_HIDDEN);
  if (moodCursorIndex == 1) lv_obj_clear_flag(ui_SelectMood2, LV_OBJ_FLAG_HIDDEN);
  if (moodCursorIndex == 2) lv_obj_clear_flag(ui_SelectMood3, LV_OBJ_FLAG_HIDDEN);
  if (moodCursorIndex == 3) lv_obj_clear_flag(ui_SelectMood4, LV_OBJ_FLAG_HIDDEN);
  if (moodCursorIndex == 4) lv_obj_clear_flag(ui_SelectMood5, LV_OBJ_FLAG_HIDDEN);
}

void enterMoodScreen()
{
  uiMode = MODE_MOOD_CURSOR;
  moodCursorIndex = 0;

  lv_scr_load_anim(
    ui_MoodScreen,
    LV_SCR_LOAD_ANIM_MOVE_LEFT,
    250,
    0,
    false
  );

  showMoodCursor();
}

void sendMood()
{
  const char *msg = nullptr;

  if (moodCursorIndex == 0) msg = "d_idle";
  else if (moodCursorIndex == 1) msg = "d_happy";
  else if (moodCursorIndex == 2) msg = "d_love";
  else if (moodCursorIndex == 3) msg = "d_sad";
  else if (moodCursorIndex == 4) msg = "d_sleep";

  if (msg == nullptr) return;

  if (!mqtt.connected() && modem.isNetworkConnected()) {
    connectMQTT();
  }

  if (mqtt.connected()) {
    mqtt.publish(TOPIC_PUB, msg);
    Serial.print("MQTT MOOD SEND: ");
    Serial.println(msg);
  } else {
    Serial.println("MQTT mood send failed: disconnected");
  }
}

void exitMoodToHome()
{
  uiMode = MODE_BASE;
  actionCursorIndex = 0;
  sendCursorIndex = 0;
  moodCursorIndex = 0;

  hideActionCursorPanels();
  hideSendCursorPanels();
  hideMoodCursorPanels();

  // Reset Action screen: quando torni su Action deve essere visibile Select2
  lv_obj_clear_flag(ui_Select2, LV_OBJ_FLAG_HIDDEN);

  currentScreen = 0;

  lv_scr_load_anim(
    ui_Home,
    LV_SCR_LOAD_ANIM_MOVE_RIGHT,
    250,
    0,
    false
  );
}


String translateIncomingMessage(const String &msg)
{
  if (msg == "r_idle") return "Sentimento neutro";
  if (msg == "r_happy") return "Sono felice";
  if (msg == "r_sad") return "Sono triste";
  if (msg == "r_love") return "Sono innamorata";
  if (msg == "r_sleep") return "Sono stanca";
  if (msg == "r_tiamo") return "Ti amo";
  if (msg == "r_mimanchi") return "Mi manchi";
  if (msg == "r_hofame") return "Ho fame";
  if (msg == "r_hosonno") return "Ho sonno";
  if (msg == "r_sonoarrabbiata") return "Sono arrabbiata";
  if (msg == "r_sonoarrabbiato") return "Sono arrabbiata";
  if (msg == "r_on") return "Mi sono svegliata";
  return msg;
}

void updateMessagesUI()
{
  if (receivedMessages.length() == 0) {
    lv_label_set_text(ui_Messages, "Non ci sono messaggi");
  } else {
    lv_label_set_text(ui_Messages, receivedMessages.c_str());
  }
}

void clearMessages()
{
  receivedMessages = "";
  hasNotification = false;
  updateMessagesUI();
  updateNotificationUI();
}

void addReceivedMessage(const String &msg)
{
  hasNotification = true;

  String translated = translateIncomingMessage(msg);

  if (receivedMessages.length() == 0) {
    receivedMessages = translated;
  } else {
    receivedMessages += "\n";
    receivedMessages += translated;
  }

  updateMessagesUI();
  updateNotificationUI();
}

void enterReceivedScreen()
{
  uiMode = MODE_RECEIVED_CURSOR;

  // Leggendo i messaggi, le notifiche vengono considerate viste
  hasNotification = false;
  updateNotificationUI();

  lv_scr_load_anim(
    ui_ReceivedScreen,
    LV_SCR_LOAD_ANIM_MOVE_LEFT,
    250,
    0,
    false
  );
}

void exitToBaseFromSubScreen()
{
  uiMode = MODE_BASE;
  actionCursorIndex = 0;
  sendCursorIndex = 0;
  moodCursorIndex = 0;

  hideActionCursorPanels();
  hideSendCursorPanels();
  hideMoodCursorPanels();

  lv_obj_clear_flag(ui_Select2, LV_OBJ_FLAG_HIDDEN);

  currentScreen = 1; // Action

  lv_scr_load_anim(
    ui_Action,
    LV_SCR_LOAD_ANIM_MOVE_RIGHT,
    250,
    0,
    false
  );
}

void hideAllSelectPanels()
{
  // Action screen selectors
  lv_obj_add_flag(ui_Select2, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_Select2a, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_Select2b, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_Select2c, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_Select2d, LV_OBJ_FLAG_HIDDEN);

  // Settings base selector
  lv_obj_add_flag(ui_Select3, LV_OBJ_FLAG_HIDDEN);

  // Mood screen selectors
  lv_obj_add_flag(ui_SelectMood1, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_SelectMood2, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_SelectMood3, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_SelectMood4, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_SelectMood5, LV_OBJ_FLAG_HIDDEN);

  // Send screen selectors
  lv_obj_add_flag(ui_SelectSend1, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_SelectSend2, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_SelectSend3, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_SelectSend4, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_SelectSend5, LV_OBJ_FLAG_HIDDEN);
}

void hideActionCursorPanels()
{
  lv_obj_add_flag(ui_Select2a, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_Select2b, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_Select2c, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_Select2d, LV_OBJ_FLAG_HIDDEN);
}

void showBaseSelectPanels()
{
  hideActionCursorPanels();

  lv_obj_clear_flag(ui_Select2, LV_OBJ_FLAG_HIDDEN);
  lv_obj_clear_flag(ui_Select3, LV_OBJ_FLAG_HIDDEN);
  lv_obj_clear_flag(ui_SelectMood1, LV_OBJ_FLAG_HIDDEN);
  lv_obj_clear_flag(ui_SelectSend1, LV_OBJ_FLAG_HIDDEN);
}

void showActionCursor()
{
  lv_obj_add_flag(ui_Select2, LV_OBJ_FLAG_HIDDEN);
  hideActionCursorPanels();

  if (actionCursorIndex == 0) lv_obj_clear_flag(ui_Select2a, LV_OBJ_FLAG_HIDDEN);
  if (actionCursorIndex == 1) lv_obj_clear_flag(ui_Select2b, LV_OBJ_FLAG_HIDDEN);
  if (actionCursorIndex == 2) lv_obj_clear_flag(ui_Select2c, LV_OBJ_FLAG_HIDDEN);
  if (actionCursorIndex == 3) lv_obj_clear_flag(ui_Select2d, LV_OBJ_FLAG_HIDDEN);
}

void enterActionCursor()
{
  uiMode = MODE_ACTION_CURSOR;
  actionCursorIndex = 0;
  showActionCursor();
}

void exitActionCursor()
{
  uiMode = MODE_BASE;
  actionCursorIndex = 0;

  hideActionCursorPanels();
  lv_obj_clear_flag(ui_Select2, LV_OBJ_FLAG_HIDDEN);
}

// =====================================================
// PMU
// =====================================================
void initPMU()
{
  if (!PMU.begin(Wire, AXP2101_SLAVE_ADDRESS, I2C_SDA, I2C_SCL)) {
    Serial.println("PMU init failed");
    return;
  }

  PMU.setChargingLedMode(XPOWERS_CHG_LED_ON);

  PMU.setBLDO1Voltage(3300);
  PMU.enableBLDO1();

  PMU.setDC3Voltage(3000);
  PMU.enableDC3();

  PMU.setBLDO2Voltage(3300);
  PMU.enableBLDO2();

  delay(500);
}

// =====================================================
// MODEM
// =====================================================
void powerOnModem()
{
  pinMode(BOARD_MODEM_PWR_PIN, OUTPUT);

  digitalWrite(BOARD_MODEM_PWR_PIN, LOW);
  delay(100);
  digitalWrite(BOARD_MODEM_PWR_PIN, HIGH);
  delay(1000);
  digitalWrite(BOARD_MODEM_PWR_PIN, LOW);

  delay(8000);
}

void initModemTime()
{
  SerialAT.begin(
    115200,
    SERIAL_8N1,
    BOARD_MODEM_RXD_PIN,
    BOARD_MODEM_TXD_PIN
  );

  powerOnModem();

  Serial.println("Testing modem...");

  for (int i = 0; i < 20; i++) {
    if (modem.testAT(1000)) {
      Serial.println("Modem OK");
      break;
    }

    Serial.print(".");
    delay(1000);
  }

  modem.init();

  Serial.println("Waiting LTE network...");
  if (modem.waitForNetwork(60000L)) {
    Serial.println("LTE connected");
    modem.gprsConnect(APN, "", "");
  } else {
    Serial.println("LTE failed");
  }
}

bool waitNetworkWithUI()
{
  for (int i = 0; i <= 60; i++) {
    if (modem.isNetworkConnected()) {
      setLoadingProgress(80, "LTE connesso");
      return true;
    }

    modem.waitForNetwork(1000L);

    int progress = 65 + min(i / 4, 14);
    setLoadingProgress(progress, "Ricerca LTE...");
  }

  setLoadingProgress(100, "LTE fallito");
  return false;
}

// =====================================================
// BATTERY
// =====================================================
int readBatteryPercent()
{
  if (!PMU.isBatteryConnect()) {
    return 0;
  }

  int battery = PMU.getBatteryPercent();

  if (battery < 0) battery = 0;
  if (battery > 100) battery = 100;

  return battery;
}

void setBatteryOnWidgets(lv_obj_t *slider, lv_obj_t *label, int battery)
{
  if (slider) {
    lv_slider_set_value(slider, battery, LV_ANIM_OFF);

    if (battery < 20) {
      lv_obj_set_style_bg_color(slider, lv_color_hex(0xFF0000), LV_PART_INDICATOR);
    } else {
      lv_obj_set_style_bg_color(slider, lv_color_hex(0x00FF66), LV_PART_INDICATOR);
    }
  }

  if (label) {
    lv_label_set_text_fmt(label, "%d%%", battery);

    if (battery < 20) {
      lv_obj_set_style_text_color(label, lv_color_hex(0xFF0000), LV_PART_MAIN);
    } else {
      lv_obj_set_style_text_color(label, lv_color_hex(0xFFFFFF), LV_PART_MAIN);
    }
  }
}

void updateBatteryUI()
{
  int battery = readBatteryPercent();

  setBatteryOnWidgets(ui_BatterySlider,  ui_BatteryText,  battery);
  setBatteryOnWidgets(ui_BatterySlider2, ui_BatteryText2, battery);
  setBatteryOnWidgets(ui_BatterySlider3, ui_BatteryText3, battery);
  setBatteryOnWidgets(ui_BatterySlider4, ui_BatteryText4, battery);
  setBatteryOnWidgets(ui_BatterySlider5, ui_BatteryText5, battery);

  lv_label_set_text_fmt(ui_BatteryStatus, "%d%%", battery);

  if (battery < 20) {
    lv_obj_set_style_text_color(ui_BatteryStatus, lv_color_hex(0xFF0000), LV_PART_MAIN);
  } else {
    lv_obj_set_style_text_color(ui_BatteryStatus, lv_color_hex(0xFFFFFF), LV_PART_MAIN);
  }
}

void forceLvglRefresh(uint16_t ms)
{
  unsigned long start = millis();

  while (millis() - start < ms) {
    lv_timer_handler();
    delay(5);
  }
}

void setLoadingProgress(int value, const char *text)
{
  value = constrain(value, 0, 100);

  lv_slider_set_value(ui_LoadingSlider, value, LV_ANIM_OFF);
  lv_label_set_text(ui_LoadingLabel, text);

  lv_obj_invalidate(ui_LoadingScreen);
  lv_refr_now(NULL);

  forceLvglRefresh(250);

  Serial.print("BOOT ");
  Serial.print(value);
  Serial.print("% - ");
  Serial.println(text);
}

// =====================================================
// TIME / STATUS
// =====================================================
void updateTimeUI()
{
  int year, month, day;
  int hour, minute, second;
  float timezone;

  bool ok = modem.getNetworkTime(
    &year,
    &month,
    &day,
    &hour,
    &minute,
    &second,
    &timezone
  );

  if (ok) {
    if (second >= 30) {
      minute++;
      if (minute >= 60) {
        minute = 0;
        hour++;
        if (hour >= 24) hour = 0;
      }
    }

    lv_label_set_text_fmt(ui_TimeText,  "%02d:%02d", hour, minute);
    lv_label_set_text_fmt(ui_TimeText2, "%02d:%02d", hour, minute);
    lv_label_set_text_fmt(ui_TimeText3, "%02d:%02d", hour, minute);
    lv_label_set_text_fmt(ui_TimeText4, "%02d:%02d", hour, minute);
    lv_label_set_text_fmt(ui_TimeText5, "%02d:%02d", hour, minute);
    lv_label_set_text_fmt(ui_TimeText6, "%02d:%02d", hour, minute);
  } else {
    lv_label_set_text(ui_TimeText,  "--:--");
    lv_label_set_text(ui_TimeText2, "--:--");
    lv_label_set_text(ui_TimeText3, "--:--");
    lv_label_set_text(ui_TimeText4, "--:--");
    lv_label_set_text(ui_TimeText5, "--:--");
    lv_label_set_text(ui_TimeText6, "--:--");
  }
}

void setWifiVisible(bool visible)
{
  lv_obj_t *wifiObjects[] = {
    ui_WifiStatus,
    ui_WifiStatus2,
    ui_WifiStatus3,
    ui_WifiStatus4,
    ui_WifiStatus5
  };

  for (int i = 0; i < 5; i++) {
    if (visible) {
      lv_obj_clear_flag(wifiObjects[i], LV_OBJ_FLAG_HIDDEN);
    } else {
      lv_obj_add_flag(wifiObjects[i], LV_OBJ_FLAG_HIDDEN);
    }
  }
}

void updateLTEStatusUI()
{
  if (modem.isNetworkConnected()) {
    lv_label_set_text(ui_LTEStatus, "LTE: Connesso");
    setWifiVisible(true);
  } else {
    lv_label_set_text(ui_LTEStatus, "LTE: Disconnesso");
    setWifiVisible(false);
  }
}


void updateUptimeUI()
{
  unsigned long totalMinutes = millis() / 60000UL;

  unsigned long days = totalMinutes / 1440UL;
  unsigned long hours = (totalMinutes % 1440UL) / 60UL;
  unsigned long minutes = totalMinutes % 60UL;

  lv_label_set_text_fmt(
    ui_Uptime,
    "Uptime: %lud %luh %lum",
    days,
    hours,
    minutes
  );
}


// =====================================================
// PERSISTENT PET STATE / OFFLINE DECAY
// =====================================================
time_t makeUnixTime(int year, int month, int day, int hour, int minute, int second)
{
  struct tm t;
  memset(&t, 0, sizeof(t));

  t.tm_year = year - 1900;
  t.tm_mon  = month - 1;
  t.tm_mday = day;
  t.tm_hour = hour;
  t.tm_min  = minute;
  t.tm_sec  = second;
  t.tm_isdst = -1;

  return mktime(&t);
}

unsigned long getNetworkUnixTime()
{
  int year, month, day;
  int hour, minute, second;
  float timezone;

  bool ok = modem.getNetworkTime(
    &year,
    &month,
    &day,
    &hour,
    &minute,
    &second,
    &timezone
  );

  if (!ok) {
    Serial.println("Network time unavailable for pet state");
    return 0;
  }

  unsigned long unixTime = (unsigned long)makeUnixTime(
    year,
    month,
    day,
    hour,
    minute,
    second
  );

  Serial.printf(
    "Pet state network time: %04d-%02d-%02d %02d:%02d:%02d -> %lu\n",
    year,
    month,
    day,
    hour,
    minute,
    second,
    unixTime
  );

  return unixTime;
}

void loadPetState()
{
  prefs.begin(NVS_NAMESPACE, true);

  foodValue = prefs.getFloat(NVS_KEY_FOOD, 100.0);
  energyValue = prefs.getFloat(NVS_KEY_ENERGY, 100.0);
  lastSavedUnixTime = prefs.getULong(NVS_KEY_LAST_UNIX, 0);

  prefs.end();

  if (foodValue < 0) foodValue = 0;
  if (foodValue > 100) foodValue = 100;
  if (energyValue < 0) energyValue = 0;
  if (energyValue > 100) energyValue = 100;

  Serial.printf(
    "Loaded pet state: food=%.1f energy=%.1f lastUnix=%lu\n",
    foodValue,
    energyValue,
    lastSavedUnixTime
  );
}

void savePetState()
{
  unsigned long nowUnix = getNetworkUnixTime();

  prefs.begin(NVS_NAMESPACE, false);

  prefs.putFloat(NVS_KEY_FOOD, foodValue);
  prefs.putFloat(NVS_KEY_ENERGY, energyValue);

  if (nowUnix > 0) {
    prefs.putULong(NVS_KEY_LAST_UNIX, nowUnix);
    lastSavedUnixTime = nowUnix;
  }

  prefs.end();

  Serial.printf(
    "Saved pet state: food=%.1f energy=%.1f unix=%lu\n",
    foodValue,
    energyValue,
    nowUnix
  );
}

void applyOfflineDecay()
{
  unsigned long nowUnix = getNetworkUnixTime();

  if (nowUnix == 0 || lastSavedUnixTime == 0 || nowUnix <= lastSavedUnixTime) {
    Serial.println("Offline decay skipped");
    return;
  }

  unsigned long elapsedSeconds = nowUnix - lastSavedUnixTime;

  foodValue -= FOOD_DECAY_PER_SECOND * elapsedSeconds;
  energyValue -= ENERGY_DECAY_PER_SECOND * elapsedSeconds;

  if (foodValue < 0) foodValue = 0;
  if (foodValue > 100) foodValue = 100;
  if (energyValue < 0) energyValue = 0;
  if (energyValue > 100) energyValue = 100;

  // Prevent applying the same offline decay twice after a normal restart.
  lastSavedUnixTime = nowUnix;

  prefs.begin(NVS_NAMESPACE, false);
  prefs.putFloat(NVS_KEY_FOOD, foodValue);
  prefs.putFloat(NVS_KEY_ENERGY, energyValue);
  prefs.putULong(NVS_KEY_LAST_UNIX, lastSavedUnixTime);
  prefs.end();

  Serial.printf(
    "Applied offline decay: elapsed=%lus food=%.1f energy=%.1f\n",
    elapsedSeconds,
    foodValue,
    energyValue
  );
}

// =====================================================
// PET VALUES
// =====================================================
void updatePetValues()
{
  unsigned long now = millis();

  if (lastPetUpdate == 0) {
    lastPetUpdate = now;
    return;
  }

  float elapsedSeconds = (now - lastPetUpdate) / 1000.0;
  lastPetUpdate = now;

  foodValue -= FOOD_DECAY_PER_SECOND * elapsedSeconds;
  energyValue -= ENERGY_DECAY_PER_SECOND * elapsedSeconds;

  if (foodValue < 0) foodValue = 0;
  if (energyValue < 0) energyValue = 0;
}

void updatePetUI()
{
  lv_label_set_text_fmt(ui_FoodValue, "%d%%", (int)foodValue);
  lv_label_set_text_fmt(ui_EnergyValue, "%d%%", (int)energyValue);
}

void hideAllKoalas()
{
  lv_obj_add_flag(ui_koalaIdleIcon, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_koalaHappyIcon, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_koalaLoveIcon, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_koalaSadIcon, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_koalaSleepyIcon, LV_OBJ_FLAG_HIDDEN);
}

void showKoala(lv_obj_t *koala)
{
  hideAllKoalas();
  lv_obj_clear_flag(koala, LV_OBJ_FLAG_HIDDEN);
}

// =====================================================
// NOTIFICATIONS
// =====================================================
void updateNotificationUI()
{
  if (hasNotification) {
    lv_obj_clear_flag(ui_Notification, LV_OBJ_FLAG_HIDDEN);
    lv_obj_clear_flag(ui_Notification2, LV_OBJ_FLAG_HIDDEN);
    lv_obj_clear_flag(ui_Notification3, LV_OBJ_FLAG_HIDDEN);
  } else {
    lv_obj_add_flag(ui_Notification, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(ui_Notification2, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(ui_Notification3, LV_OBJ_FLAG_HIDDEN);
  }
}

void setNotificationReceived()
{
  hasNotification = true;
  updateNotificationUI();
}

// =====================================================
// MQTT
// =====================================================
void mqttCallback(char *topic, byte *payload, unsigned int len)
{
  String msg = "";

  for (unsigned int i = 0; i < len; i++) {
    msg += (char)payload[i];
  }

  msg.trim();

  Serial.print("MQTT RX: ");
  Serial.println(msg);

  if (msg.startsWith("r_")) {
    addReceivedMessage(msg);
  }

  if (msg == "r_food") {
    foodValue = 100;
    updatePetUI();
  } else if (msg == "r_energy") {
    energyValue = 100;
    updatePetUI();
  } else if (msg == "r_idle") {
    showKoala(ui_koalaIdleIcon);
  } else if (msg == "r_happy") {
    showKoala(ui_koalaHappyIcon);
  } else if (msg == "r_love") {
    showKoala(ui_koalaLoveIcon);
  } else if (msg == "r_sad") {
    showKoala(ui_koalaSadIcon);
  } else if (msg == "r_sleep") {
    showKoala(ui_koalaSleepyIcon);
  }
}

bool connectMQTT()
{
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setCallback(mqttCallback);

  if (mqtt.connected()) {
    lv_label_set_text(ui_MQTTStatus, "MQTT: Connesso");
    return true;
  }

  Serial.println("Connecting MQTT...");

  if (mqtt.connect(MQTT_CLIENT_ID, MQTT_USER, MQTT_PASS)) {
    Serial.println("MQTT connected");

    mqtt.subscribe(TOPIC_SUB);
    mqtt.publish(TOPIC_PUB, "d_on");
    mqtt.publish(TOPIC_PUB, "d_idle");

    lv_label_set_text(ui_MQTTStatus, "MQTT: Connesso");
    return true;
  }

  Serial.print("MQTT failed, state=");
  Serial.println(mqtt.state());

  lv_label_set_text(ui_MQTTStatus, "MQTT: Disconnesso");
  return false;
}

void updateMQTTStatusUI()
{
  if (mqtt.connected()) {
    lv_label_set_text(ui_MQTTStatus, "MQTT: Connesso");
  } else {
    lv_label_set_text(ui_MQTTStatus, "MQTT: Disconnesso");
  }
}

// =====================================================
// BUTTONS
// =====================================================
bool buttonPressed(int pin)
{
  static unsigned long lastLeft = 0;
  static unsigned long lastRight = 0;
  static unsigned long lastUp = 0;
  static unsigned long lastDown = 0;
  static unsigned long lastSelect = 0;

  unsigned long *last;

  if (pin == BTN_LEFT) {
    last = &lastLeft;
  } else if (pin == BTN_RIGHT) {
    last = &lastRight;
  } else if (pin == BTN_UP) {
    last = &lastUp;
  } else if (pin == BTN_DOWN) {
    last = &lastDown;
  } else {
    last = &lastSelect;
  }

  if (digitalRead(pin) == LOW && millis() - *last > 300) {
    *last = millis();
    return true;
  }

  return false;
}

// =====================================================
// SCREEN NAVIGATION
// =====================================================
void showScreenLeftEffect(int index)
{
  if (index < 0) index = SCREEN_COUNT - 1;
  if (index >= SCREEN_COUNT) index = 0;

  currentScreen = index;

  lv_scr_load_anim(
    screenList[currentScreen],
    LV_SCR_LOAD_ANIM_MOVE_LEFT,
    250,
    0,
    false
  );
}

void showScreenRightEffect(int index)
{
  if (index < 0) index = SCREEN_COUNT - 1;
  if (index >= SCREEN_COUNT) index = 0;

  currentScreen = index;

  lv_scr_load_anim(
    screenList[currentScreen],
    LV_SCR_LOAD_ANIM_MOVE_RIGHT,
    250,
    0,
    false
  );
}

// =====================================================
// SLEEP SYSTEM
// =====================================================
void setupButtonInput(int pin)
{
  pinMode(pin, INPUT_PULLUP);
}

void configureWakeButtonRTC(int pin)
{
  rtc_gpio_init((gpio_num_t)pin);
  rtc_gpio_set_direction((gpio_num_t)pin, RTC_GPIO_MODE_INPUT_ONLY);
  rtc_gpio_pullup_en((gpio_num_t)pin);
  rtc_gpio_pulldown_dis((gpio_num_t)pin);
}

void configureWakeButtons()
{
  setupButtonInput(BTN_LEFT);
  setupButtonInput(BTN_RIGHT);
  setupButtonInput(BTN_UP);
  setupButtonInput(BTN_DOWN);
  setupButtonInput(BTN_SELECT);

  configureWakeButtonRTC(BTN_LEFT);
  configureWakeButtonRTC(BTN_RIGHT);
  configureWakeButtonRTC(BTN_UP);
  // BTN_DOWN è GPIO45: usato come pulsante normale, NON come wake RTC
  configureWakeButtonRTC(BTN_SELECT);
}

void registerUserActivity()
{
  lastUserActivity = millis();

  if (screenDimmed) {
    screenDimmed = false;
  }

  ledcWrite(TFT_BL, BACKLIGHT_NORMAL);
}

void publishSleepBeforeDeepSleep()
{
  if (!mqtt.connected() && modem.isNetworkConnected()) {
    connectMQTT();
  }

  if (mqtt.connected()) {
    mqtt.publish(TOPIC_PUB, "d_sleep");
    mqtt.loop();
    Serial.println("MQTT SEND BEFORE SLEEP: d_sleep");
    delay(300);
  } else {
    Serial.println("MQTT sleep send skipped: disconnected");
  }
}

void prepareForDeepSleep()
{
  Serial.println("Preparing deep sleep...");

  publishSleepBeforeDeepSleep();

  // Save food/energy and timestamp before shutting down the modem.
  savePetState();

  // Spegne retroilluminazione
  ledcWrite(TFT_BL, 0);
  delay(100);

  // Disconnette MQTT
  if (mqtt.connected()) {
    mqtt.disconnect();
  }

  // Spegne modem SIM7080
  modem.poweroff();
  delay(500);

  // Toglie alimentazione modem
  PMU.disableDC3();

  // Toglie alimentazione antenna/GPS se usata
  PMU.disableBLDO2();

  delay(300);
}

void enterDeepSleep()
{
  prepareForDeepSleep();

  // Wake-up da pulsanti verso GND.
  // BTN_DOWN/GPIO45 NON è incluso perché non è valido per EXT1 wake.
  esp_err_t err = esp_sleep_enable_ext1_wakeup(WAKEUP_BUTTON_MASK, ESP_EXT1_WAKEUP_ANY_LOW);
  Serial.printf("EXT1 wake config result = %d\n", err);

  Serial.println("Entering deep sleep...");
  delay(100);

  esp_deep_sleep_start();
}


void handleSleepSystem()
{
  unsigned long inactive = millis() - lastUserActivity;

  // Dopo 3 minuti: luminosità bassa
  if (!screenDimmed && inactive >= DIM_AFTER_MS) {
    screenDimmed = true;
    ledcWrite(TFT_BL, BACKLIGHT_DIM);
    Serial.println("Display dimmed");
  }

  // Dopo 1 minuto aggiuntivo: deep sleep
  if (screenDimmed && inactive >= DIM_AFTER_MS + DEEP_SLEEP_AFTER_MS) {
    enterDeepSleep();
  }
}

// =====================================================
// SETUP
// =====================================================
void setup()
{
  Serial.begin(115200);
  delay(1000);

  pinMode(BTN_LEFT, INPUT_PULLUP);
  pinMode(BTN_RIGHT, INPUT_PULLUP);
  pinMode(BTN_UP, INPUT_PULLUP);
  pinMode(BTN_DOWN, INPUT_PULLUP);
  pinMode(BTN_SELECT, INPUT_PULLUP);

  Serial.println("Starting Tamagochi");

  configureWakeButtons();

  ledcAttach(TFT_BL, 5000, 8);
  ledcWrite(TFT_BL, BACKLIGHT_NORMAL);

  lastUserActivity = millis();

  gfx->begin(40000000);
  gfx->fillScreen(0x0000);

  lv_init();

  lv_disp_draw_buf_init(&draw_buf, buf, NULL, 240 * 40);

  lv_disp_drv_init(&disp_drv);
  disp_drv.hor_res = 240;
  disp_drv.ver_res = 280;
  disp_drv.flush_cb = my_disp_flush;
  disp_drv.draw_buf = &draw_buf;

  lv_disp_drv_register(&disp_drv);

  ui_init();

  showBaseSelectPanels();

  lv_obj_add_flag(ui_SendConfirmed, LV_OBJ_FLAG_HIDDEN);

  hideSendCursorPanels();
  hideMoodCursorPanels();
  updateMessagesUI();

  // Restore saved food/energy immediately. Offline decay is applied later,
  // once the cellular network time is available.
  loadPetState();

  lv_obj_add_flag(ui_Select2a, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_Select2b, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_Select2c, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(ui_Select2d, LV_OBJ_FLAG_HIDDEN);

  // Only these 3 are base screens for LEFT/RIGHT navigation
  screenList[0] = ui_Home;
  screenList[1] = ui_Action;
  screenList[2] = ui_Settings;

  lv_scr_load(ui_LoadingScreen);
  lv_refr_now(NULL);
  forceLvglRefresh(500);

  setLoadingProgress(0, "Avvio...");

  initPMU();
  setLoadingProgress(15, "PMU pronta");

  SerialAT.begin(115200, SERIAL_8N1, BOARD_MODEM_RXD_PIN, BOARD_MODEM_TXD_PIN);
  setLoadingProgress(25, "UART modem pronta");

  powerOnModem();
  setLoadingProgress(35, "Modem acceso");

  bool atOk = false;
  for (int i = 0; i < 20; i++) {
    if (modem.testAT(1000)) {
      atOk = true;
      break;
    }
    setLoadingProgress(35 + i, "Attesa AT...");
  }

  if (!atOk) {
    setLoadingProgress(100, "Errore AT");
    delay(1200);
    lv_scr_load(ui_Home);

    showKoala(ui_koalaIdleIcon);
    updatePetUI();
    hasNotification = false;
    updateNotificationUI();
    updateBatteryUI();
    updateLTEStatusUI();
    updateUptimeUI();
    updateMQTTStatusUI();

    Serial.println("Ready without modem");
    return;
  }

  setLoadingProgress(55, "AT OK");

  modem.init();
  setLoadingProgress(65, "Modem inizializzato");

  bool netOk = waitNetworkWithUI();

  bool apnOk = false;
  if (netOk) {
    apnOk = modem.gprsConnect(APN, "", "");
  }
  setLoadingProgress(apnOk ? 90 : 100, apnOk ? "APN connesso" : "APN fallito");

  bool mqttOk = false;
  if (apnOk) {
    mqttOk = connectMQTT();
  }
  setLoadingProgress(100, mqttOk ? "MQTT connesso" : "MQTT fallito");

  delay(800);
  lv_scr_load(ui_Home);

  // Now that network time is available, calculate how much food/energy
  // was lost while the ESP32 was in deep sleep.
  applyOfflineDecay();

  showKoala(ui_koalaIdleIcon);
  updatePetUI();
  hasNotification = false;
  updateNotificationUI();
  updateBatteryUI();
  updateTimeUI();
  updateLTEStatusUI();
  updateUptimeUI();
  updateMQTTStatusUI();

  Serial.println("Ready");
}

// =====================================================
// LOOP
// =====================================================
void loop()
{
  static unsigned long lastTick = millis();
  unsigned long now = millis();

  lv_tick_inc(now - lastTick);
  lastTick = now;

  lv_timer_handler();

  // ================= SELECT =================
  // In MoodScreen il SELECT deve essere tenuto 1 secondo.
  // Per questo lo gestiamo con digitalRead() e NON con buttonPressed().
  if (uiMode == MODE_MOOD_CURSOR) {
    if (digitalRead(BTN_SELECT) == LOW) {
      registerUserActivity();

      if (!selectIsPressed) {
        selectIsPressed = true;
        selectLongHandled = false;
        selectPressStart = millis();
      }

      if (!selectLongHandled && millis() - selectPressStart >= 1000) {
        selectLongHandled = true;
        sendMood();
        exitMoodToHome();
      }
    } else {
      selectIsPressed = false;
      selectLongHandled = false;
    }
  }
  else if (buttonPressed(BTN_SELECT)) {
    registerUserActivity();

    if (currentScreen == 1 && uiMode == MODE_BASE) {
      enterActionCursor();
    }

    else if (uiMode == MODE_ACTION_CURSOR) {
      if (actionCursorIndex == 0) {        // Select2a
        enterSendScreen();
      }
      else if (actionCursorIndex == 1) {   // Select2b
        enterMoodScreen();
      }
      else if (actionCursorIndex == 2) {   // Select2c
        enterReceivedScreen();
      }
      else if (actionCursorIndex == 3) {   // Select2d
        enterDeepSleep();
      }
    }

    else if (uiMode == MODE_SEND_CURSOR) {
      sendSelectedMessage();
    }

    else if (uiMode == MODE_RECEIVED_CURSOR) {
      clearMessages();
    }
  }

  // ================= LEFT =================
  // Pressione corta:
  // - base: pagina precedente
  // - action cursor: su
  // - send/received: niente
  // Pressione lunga 2s:
  // - action cursor, solo colonna sinistra: torna alla base
  // - send/received: torna ad Action con Select2 visibile
  if (digitalRead(BTN_LEFT) == LOW) {
    registerUserActivity();

    if (!leftIsPressed) {
      leftIsPressed = true;
      leftLongHandled = false;
      leftPressStart = millis();
    }

    if (!leftLongHandled && millis() - leftPressStart >= 2000) {
      leftLongHandled = true;

      if (uiMode == MODE_SEND_CURSOR || uiMode == MODE_RECEIVED_CURSOR) {
        exitToBaseFromSubScreen();
      }
      else if (uiMode == MODE_ACTION_CURSOR) {
        // Long LEFT always exits Action cursor mode, from any Select2a/b/c/d position.
        exitActionCursor();
      }
    }
  } else {
    if (leftIsPressed && !leftLongHandled) {
      registerUserActivity();

      if (uiMode == MODE_ACTION_CURSOR) {
        // LEFT corto = su
        if (actionCursorIndex == 2) actionCursorIndex = 0;
        else if (actionCursorIndex == 3) actionCursorIndex = 1;
        showActionCursor();
      }
      else if (uiMode == MODE_MOOD_CURSOR) {
        // MoodScreen: LEFT = sinistra
        if (moodCursorIndex == 1) moodCursorIndex = 0;
        else if (moodCursorIndex == 3) moodCursorIndex = 2;
        showMoodCursor();
      }
      else if (uiMode == MODE_SEND_CURSOR || uiMode == MODE_RECEIVED_CURSOR) {
        // LEFT corto non fa nulla nelle sotto-schermate
      }
      else {
        showScreenRightEffect(currentScreen - 1);
      }
    }

    leftIsPressed = false;
    leftLongHandled = false;
  }

  // ================= RIGHT =================
  if (buttonPressed(BTN_RIGHT)) {
    registerUserActivity();

    if (uiMode == MODE_ACTION_CURSOR) {
      // RIGHT = giù
      if (actionCursorIndex == 0) actionCursorIndex = 2;
      else if (actionCursorIndex == 1) actionCursorIndex = 3;
      showActionCursor();
    }
    else if (uiMode == MODE_MOOD_CURSOR) {
      // MoodScreen: RIGHT = destra
      if (moodCursorIndex == 0) moodCursorIndex = 1;
      else if (moodCursorIndex == 2) moodCursorIndex = 3;
      showMoodCursor();
    }
    else if (uiMode == MODE_SEND_CURSOR || uiMode == MODE_RECEIVED_CURSOR) {
      // In SendScreen e ReceivedScreen, RIGHT non fa nulla
    }
    else {
      showScreenLeftEffect(currentScreen + 1);
    }
  }

  // ================= UP =================
  if (buttonPressed(BTN_UP)) {
    registerUserActivity();

    if (uiMode == MODE_ACTION_CURSOR) {
      // UP = sinistra
      if (actionCursorIndex == 1) actionCursorIndex = 0;
      else if (actionCursorIndex == 3) actionCursorIndex = 2;
      showActionCursor();
    }
    else if (uiMode == MODE_SEND_CURSOR) {
      // SendScreen: su
      sendCursorIndex--;
      if (sendCursorIndex < 0) sendCursorIndex = 0;
      showSendCursor();
    }
    else if (uiMode == MODE_MOOD_CURSOR) {
      // MoodScreen: UP = su
      if (moodCursorIndex == 2) moodCursorIndex = 0;
      else if (moodCursorIndex == 3) moodCursorIndex = 1;
      else if (moodCursorIndex == 4) moodCursorIndex = 2;
      showMoodCursor();
    }
  }

  // ================= DOWN =================
  if (buttonPressed(BTN_DOWN)) {
    registerUserActivity();

    if (uiMode == MODE_ACTION_CURSOR) {
      // DOWN = destra
      if (actionCursorIndex == 0) actionCursorIndex = 1;
      else if (actionCursorIndex == 2) actionCursorIndex = 3;
      showActionCursor();
    }
    else if (uiMode == MODE_SEND_CURSOR) {
      // SendScreen: giù
      sendCursorIndex++;
      if (sendCursorIndex > 4) sendCursorIndex = 4;
      showSendCursor();
    }
    else if (uiMode == MODE_MOOD_CURSOR) {
      // MoodScreen: DOWN = giù
      if (moodCursorIndex == 0) moodCursorIndex = 2;
      else if (moodCursorIndex == 1) moodCursorIndex = 3;
      else if (moodCursorIndex == 2) moodCursorIndex = 4;
      showMoodCursor();
    }
  }

  if (millis() - lastUiUpdate > 5000) {
    lastUiUpdate = millis();

    updateBatteryUI();
    updateLTEStatusUI();
    updateUptimeUI();
    updatePetValues();
    updatePetUI();

    if (!mqtt.connected() && modem.isNetworkConnected()) {
      connectMQTT();
    }

    updateMQTTStatusUI();
  }

  if (millis() - lastTimeUpdate > 10000) {
    lastTimeUpdate = millis();
    updateTimeUI();
  }

  if (mqtt.connected()) {
    mqtt.loop();
  }

  handleSendConfirmedTimeout();
  handleSleepSystem();

  delay(5);
}
